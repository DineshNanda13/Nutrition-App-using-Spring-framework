package com.NutritionApp;

public class MondayDiet implements Diet {

	@Override
	public String getDiet() {
		return "Monday: Eat boiled veggies";
	}

	@Override
	public String getDailyWorkouts() {
		// TODO Auto-generated method stub
		return null;
	}

}
