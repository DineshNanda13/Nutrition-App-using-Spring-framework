package com.NutritionApp;

public interface Diet {
	
	public String getDiet();
	
	public String getDailyWorkouts();

}
