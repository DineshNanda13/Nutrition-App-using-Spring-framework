package com.NutritionApp;

public class WednesdayDiet implements Diet {

	@Override
	public String getDiet() {
		return "Wednesday: Eat boiled fish";
	}

	@Override
	public String getDailyWorkouts() {
		// TODO Auto-generated method stub
		return null;
	}

}
