package com.NutritionApp;

public class TuesdayDiet implements Diet {

	@Override
	public String getDiet() {
		return "Tuesday: Eat boiled chicken breast";
	}

	@Override
	public String getDailyWorkouts() {
		// TODO Auto-generated method stub
		return null;
	}

}
