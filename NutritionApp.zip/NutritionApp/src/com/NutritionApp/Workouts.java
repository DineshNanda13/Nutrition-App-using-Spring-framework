package com.NutritionApp;

public interface Workouts {
	
	public String getWorkouts();
}
